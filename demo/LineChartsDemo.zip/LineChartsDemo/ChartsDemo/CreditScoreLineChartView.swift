//
//  CreditScoreLineChartView.swift
//  ChartsDemo
//
//  Created by jzhang on 6/22/21.
//

import Charts
import Foundation

class CreditScoreLineChartView: LineChartView {
    // 修复双击自动取消选中效果的bug
    override func zoom(scaleX: CGFloat, scaleY: CGFloat, x: CGFloat, y: CGFloat) {}
}
