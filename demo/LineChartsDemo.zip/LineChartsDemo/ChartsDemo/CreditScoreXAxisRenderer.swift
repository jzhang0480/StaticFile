//
//  CreditScoreXAxisRenderer.swift
//  ChartsDemo
//
//  Created by Jie Zhang on 6/22/21.
//

import Charts

import Foundation

class CreditScoreXAxisRenderer: XAxisRenderer {
    var selectedLabel: String?
    
    override func drawLabel(
        context: CGContext,
        formattedLabel: String,
        x: CGFloat, y: CGFloat,
        attributes: [NSAttributedString.Key: Any],
        constrainedTo size: CGSize,
        anchor: CGPoint,
        angleRadians: CGFloat)
    {
        if formattedLabel == selectedLabel {
            var selectedAttributes = attributes
            selectedAttributes[.font] = UIFont.boldSystemFont(ofSize: 12)
            selectedAttributes[.foregroundColor] = UIColor.black
            
            super.drawLabel(context: context,
                            formattedLabel: formattedLabel,
                            x: x,
                            y: y,
                            attributes: selectedAttributes,
                            constrainedTo: size,
                            anchor: anchor,
                            angleRadians: angleRadians)
        } else {
            super.drawLabel(context: context,
                            formattedLabel: formattedLabel,
                            x: x,
                            y: y,
                            attributes: attributes,
                            constrainedTo: size,
                            anchor: anchor,
                            angleRadians: angleRadians)
        }
    }
}
