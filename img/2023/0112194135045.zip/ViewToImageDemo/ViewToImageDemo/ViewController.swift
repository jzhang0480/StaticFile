//
//  ViewController.swift
//  ViewToImageDemo
//
//  Created by Jie Zhang on 2023/1/12.
//

import UIKit

class ViewController: UIViewController {
    let stackView = UIStackView()
    @IBOutlet weak var imageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        let imageView = UIImageView()
        imageView.image = UIImage(named: "ic-ce-business")

        let label = UILabel()
        label.text = "title"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 11)

        stackView.backgroundColor = UIColor.red
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.alignment = .center
        stackView.axis = .vertical
        stackView.spacing = 8

        stackView.addArrangedSubview(imageView)
        stackView.addArrangedSubview(label)

        let size = stackView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        let finalImage = stackView.asImage(size)
        self.imageView.image = finalImage
    }
}

extension UIView {
    // 将当前视图转为UIImage
    func asImage(_ inputSize: CGSize = .zero) -> UIImage {
        let size: CGSize = inputSize == .zero ? bounds.size : inputSize
        let renderer = UIGraphicsImageRenderer(size: size)
        let finalImage = renderer.image { context in
            drawHierarchy(in: CGRect(x: 0, y: 0, width: size.width, height: size.height), afterScreenUpdates: true)
        }
        return finalImage
    }
}
