//
//  ViewController.swift
//  ObfuscateStringDemo
//
//  Created by Jie Zhang on 2022/4/30.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 使用原生类来生成salt是目前最好的方式
        let o = Obfuscator(with: [AppDelegate.self, NSObject.self].description)
        
        // 通过o.bytesByObfuscatingString(string: "password")提前生成了bytes
        let bytes: [UInt8] = [43, 46, 17, 21, 2, 28, 17, 5]
        let password = o.reveal(key: bytes)
    }
}
